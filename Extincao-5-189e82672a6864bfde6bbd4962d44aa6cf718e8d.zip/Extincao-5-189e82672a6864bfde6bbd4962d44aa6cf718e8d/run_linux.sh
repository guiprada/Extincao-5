#!/bin/sh
./love/love-11.4-x86_64.AppImage ./
